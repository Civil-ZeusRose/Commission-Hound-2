player_manager.AddValidModel( "Leon S. Kennedy (RE4)", 				"models/players/mj_re4_leon.mdl" )
list.Set( "PlayerOptionsModel",  "Leon S. Kennedy (RE4)",				"models/players/mj_re4_leon.mdl" )
player_manager.AddValidHands(	"Leon S. Kennedy (RE4)", "models/players/mj_re4_leon_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Leon S. Kennedy (RE4) (Mafia)", 				"models/players/mj_re4_leon_mafia.mdl" )
list.Set( "PlayerOptionsModel",  "Leon S. Kennedy (RE4) (Mafia)",				"models/players/mj_re4_leon_mafia.mdl" )
player_manager.AddValidHands(	"Leon S. Kennedy (RE4) (Mafia)", "models/players/mj_re4_leon_mafia_arms.mdl", 0, "00000000" )

local Category = "Resident Evil" 

local NPC =
{
	Name = "Leon S. Kennedy (RE4) - Friendly",
	Class = "npc_citizen",
	Health = "100",
	KeyValues = { citizentype = 4 },
	Model = "models/players/mj_re4_leon_npc.mdl",
	Category = Category
}

list.Set( "NPC", "re4_leon_ally", NPC )

local NPC =
{
	Name = "Leon S. Kennedy (RE4) (Mafia) - Friendly",
	Class = "npc_citizen",
	Health = "100",
	KeyValues = { citizentype = 4 },
	Model = "models/players/mj_re4_leon_mafia_npc.mdl",
	Category = Category
}

list.Set( "NPC", "re4_leon_mafia_ally", NPC )
